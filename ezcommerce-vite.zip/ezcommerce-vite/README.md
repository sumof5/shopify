# EzCommerce (Vite + React + Tailwind)
Demo e-commerce frontend (grid produk, carian, filter, troli, subtotal). Checkout mock alert.

## Cara run (lokal)
1. `npm i`
2. `npm run dev`
3. Buka `http://localhost:5173`

## Cara preview di StackBlitz
- Pergi https://stackblitz.com
- Klik **Create Project → Vite React** (atau terus **Upload Project**)
- **Drag & drop** fail zip ini ke StackBlitz → projek akan run automatik.

## Integrasi seterusnya
- Sambung ke API checkout (ToyyibPay) & Supabase seperti dokumen panduan saya.
