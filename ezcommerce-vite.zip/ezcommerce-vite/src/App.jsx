import React, { useMemo, useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const CATEGORIES = [
  { id: "all", name: "All" },
  { id: "apparel", name: "Apparel" },
  { id: "electronics", name: "Electronics" },
  { id: "books", name: "Books" },
];

const PRODUCTS = [
  {
    id: "p1",
    name: "Minimal Tee",
    price: 59.0,
    image: "https://images.unsplash.com/photo-1520975922284-9f2d09c5a283?q=80&w=800&auto=format&fit=crop",
    category: "apparel",
    badge: "Bestseller",
  },
  {
    id: "p2",
    name: "Wireless Earbuds",
    price: 199.0,
    image: "https://images.unsplash.com/photo-1585386959984-a4155223168f?q=80&w=800&auto=format&fit=crop",
    category: "electronics",
    badge: "New",
  },
  {
    id: "p3",
    name: "Productivity Book",
    price: 39.0,
    image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?q=80&w=800&auto=format&fit=crop",
    category: "books",
  },
  {
    id: "p4",
    name: "Hoodie Pro",
    price: 129.0,
    image: "https://images.unsplash.com/photo-1542060748-10c28b62716a?q=80&w=800&auto=format&fit=crop",
    category: "apparel",
  },
  {
    id: "p5",
    name: "Smart Watch Lite",
    price: 299.0,
    image: "https://images.unsplash.com/photo-1517059224940-d4af9eec41e5?q=80&w=800&auto=format&fit=crop",
    category: "electronics",
  },
  {
    id: "p6",
    name: "Desk Lamp",
    price: 79.0,
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=800&auto=format&fit=crop",
    category: "electronics",
  },
];

function formatMYR(n) {
  return new Intl.NumberFormat("ms-MY", { style: "currency", currency: "MYR" }).format(n);
}

function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });
  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {}
  }, [key, value]);
  return [value, setValue];
}

function Header({ cartCount, onOpenCart }) {
  return (
    <div className="sticky top-0 z-30 backdrop-blur bg-white/70 border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-black text-white grid place-items-center font-bold">EZ</div>
          <div className="font-semibold text-xl">EzCommerce</div>
        </div>
        <button onClick={onOpenCart} className="relative px-4 py-2 rounded-xl border hover:shadow">
          Cart
          {cartCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-black text-white text-xs px-2 py-0.5 rounded-full">
              {cartCount}
            </span>
          )}
        </button>
      </div>
    </div>
  );
}

function Filters({ query, setQuery, category, setCategory }) {
  return (
    <div className="max-w-6xl mx-auto px-4 mt-6 grid grid-cols-1 md:grid-cols-3 gap-3">
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Cari produk..."
        className="w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-black/20 outline-none"
      />
      <select
        value={category}
        onChange={(e) => setCategory(e.target.value)}
        className="w-full px-4 py-3 rounded-xl border"
      >
        {CATEGORIES.map((c) => (
          <option key={c.id} value={c.id}>{c.name}</option>
        ))}
      </select>
      <div className="text-sm text-gray-500 flex items-center">* Demo frontend. Sambung ke payment gateway untuk live checkout.</div>
    </div>
  );
}

function ProductCard({ p, onAdd }) {
  return (
    <motion.div layout className="group border rounded-2xl overflow-hidden bg-white hover:shadow-lg transition" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
      <div className="aspect-square overflow-hidden">
        <img src={p.image} alt={p.name} className="h-full w-full object-cover group-hover:scale-105 transition" />
      </div>
      <div className="p-4 space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold line-clamp-1">{p.name}</h3>
          {p.badge && <span className="text-xs bg-black text-white px-2 py-0.5 rounded-full">{p.badge}</span>}
        </div>
        <div className="text-gray-500 text-sm capitalize">{p.category}</div>
        <div className="flex items-center justify-between">
          <div className="text-lg font-semibold">{formatMYR(p.price)}</div>
          <button onClick={() => onAdd(p)} className="px-3 py-2 rounded-xl border hover:bg-black hover:text-white transition">Tambah</button>
        </div>
      </div>
    </motion.div>
  );
}

function ProductGrid({ items, onAdd }) {
  return (
    <div className="max-w-6xl mx-auto px-4 mt-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
      <AnimatePresence>
        {items.map((p) => (
          <ProductCard key={p.id} p={p} onAdd={onAdd} />
        ))}
      </AnimatePresence>
    </div>
  );
}

function Cart({ open, onClose, items, setItems }) {
  const subtotal = useMemo(() => items.reduce((s, it) => s + it.price * it.qty, 0), [items]);

  function inc(id) {
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, qty: it.qty + 1 } : it)));
  }
  function dec(id) {
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, qty: Math.max(1, it.qty - 1) } : it)));
  }
  function remove(id) {
    setItems((prev) => prev.filter((it) => it.id !== id));
  }
  function checkout() {
    alert("Demo sahaja. Sambung ke ToyyibPay / Billplz / iPay88 / Stripe.");
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-40" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-black/40" onClick={onClose} />
          <motion.div
            className="absolute right-0 top-0 h-full w-full sm:w-[420px] bg-white shadow-2xl p-4 flex flex-col"
            initial={{ x: 500 }}
            animate={{ x: 0 }}
            exit={{ x: 500 }}
            transition={{ type: "spring", stiffness: 260, damping: 30 }}
          >
            <div className="flex items-centered justify-between mb-3">
              <h2 className="text-lg font-semibold">Troli</h2>
              <button onClick={onClose} className="px-3 py-1.5 rounded-lg border">Tutup</button>
            </div>

            <div className="flex-1 overflow-auto space-y-3">
              {items.length === 0 && <div className="text-gray-500">Tiada item dalam troli.</div>}
              {items.map((it) => (
                <div key={it.id} className="flex gap-3 border rounded-xl p-2">
                  <img src={it.image} alt={it.name} className="w-16 h-16 rounded-lg object-cover" />
                  <div className="flex-1">
                    <div className="font-medium line-clamp-1">{it.name}</div>
                    <div className="text-sm text-gray-500">{formatMYR(it.price)}</div>
                    <div className="flex items-center gap-2 mt-2">
                      <button onClick={() => dec(it.id)} className="px-2 py-1 border rounded-lg">-</button>
                      <span>{it.qty}</span>
                      <button onClick={() => inc(it.id)} className="px-2 py-1 border rounded-lg">+</button>
                      <button onClick={() => remove(it.id)} className="ml-auto text-red-600 text-sm">Buang</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t pt-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Subtotal</span>
                <span className="font-semibold">{formatMYR(subtotal)}</span>
              </div>
              <button onClick={checkout} className="w-full py-3 rounded-xl bg-black text-white font-semibold">Teruskan ke Pembayaran</button>
              <div className="text-xs text-gray-500">* Cukai & penghantaran dikira semasa checkout.</div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default function App() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useLocalStorage("demo-cart", []);

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return PRODUCTS.filter((p) => {
      const matchQ = p.name.toLowerCase().includes(q);
      const matchC = category === "all" ? true : p.category === category;
      return matchQ && matchC;
    });
  }, [query, category]);

  function addToCart(p) {
    setCart((prev) => {
      const found = prev.find((it) => it.id === p.id);
      if (found) return prev.map((it) => (it.id === p.id ? { ...it, qty: it.qty + 1 } : it));
      return [...prev, { ...p, qty: 1 }];
    });
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="sticky top-0 z-30 backdrop-blur bg-white/70 border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-black text-white grid place-items-center font-bold">EZ</div>
            <div className="font-semibold text-xl">EzCommerce</div>
          </div>
          <button onClick={() => setCartOpen(true)} className="relative px-4 py-2 rounded-xl border hover:shadow">
            Cart
            {cart.reduce((s, it) => s + it.qty, 0) > 0 && (
              <span className="absolute -top-2 -right-2 bg-black text-white text-xs px-2 py-0.5 rounded-full">
                {cart.reduce((s, it) => s + it.qty, 0)}
              </span>
            )}
          </button>
        </div>
      </div>

      <section className="max-w-6xl mx-auto px-4 pt-8">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-3xl bg-gradient-to-br from-black to-neutral-800 text-white p-8">
          <div className="text-sm opacity-80 mb-2">Ecommerce Starter</div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Launch kedai online gaya Shopify</h1>
          <p className="opacity-80">Produk grid + troli + siap sambung payment gateway tempatan (ToyyibPay/Billplz/iPay88/Stripe). Frontend siap pakai — tinggal connect API.</p>
          <div className="mt-4 flex flex-wrap gap-2 text-xs">
            <span className="px-2 py-1 rounded-full bg-white/10">React</span>
            <span className="px-2 py-1 rounded-full bg-white/10">Tailwind</span>
            <span className="px-2 py-1 rounded-full bg-white/10">Framer Motion</span>
            <span className="px-2 py-1 rounded-full bg-white/10">LocalStorage Cart</span>
          </div>
        </motion.div>
      </section>

      <div className="max-w-6xl mx-auto px-4 mt-6 grid grid-cols-1 md:grid-cols-3 gap-3">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Cari produk..."
          className="w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-black/20 outline-none"
        />
        <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full px-4 py-3 rounded-xl border">
          {CATEGORIES.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <div className="text-sm text-gray-500 flex items-center">* Demo frontend. Sambung ke payment gateway untuk live checkout.</div>
      </div>

      <div className="max-w-6xl mx-auto px-4 mt-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
        <AnimatePresence>
          {filtered.map((p) => (
            <ProductCard key={p.id} p={p} onAdd={addToCart} />
          ))}
        </AnimatePresence>
      </div>

      <footer className="max-w-6xl mx-auto px-4 py-10 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} EzCommerce. Built for demo — minta saya sambung ke backend & payment.
      </footer>

      <Cart open={cartOpen} onClose={() => setCartOpen(false)} items={cart} setItems={setCart} />
    </div>
  );
}
